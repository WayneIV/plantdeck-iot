# Test camera capture
import cv2