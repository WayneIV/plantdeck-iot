# Detect leaf discoloration
import cv2