# PlantDeck-IoT

Smart plant monitoring system using Arduino/ESP32.

## Features
- Moisture, NPK, PAR sensors
- Web dashboard via ESP32
- Future OpenCV integration