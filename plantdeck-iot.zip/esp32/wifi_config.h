// Wi-Fi config
const char* ssid = "YOUR_SSID";
const char* password = "YOUR_PASS";